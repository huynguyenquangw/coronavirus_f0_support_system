import React from 'react'

function Dashboard(props) {

    return (
        <div>
            <h1 style={{ fontSize: "10em" }}>Dashboard</h1>
        </div>
    )
}

export default Dashboard
